// # INTEGRATE: This entire file will be replaced by your authentication system's user data.
export const MOCK_USERS_DB = [
  { id: 1, name: "Recruiter", email: "recruiter@buxton.com", role: "recruiter", managerId: 5, status: 'Active' },
  { id: 2, name: "Account Manager", email: "manager@buxton.com", role: "account_manager", managerId: 5, status: 'Active' },
  { id: 3, name: "Admin", email: "admin@buxton.com", role: "admin", managerId: null, status: 'Active' },
  { id: 4, name: "Technical Reviewer", email: "tech@buxton.com", role: "technical_manager", managerId: 5, status: 'Active' },
  { id: 5, name: "Executive", email: "executive@buxton.com", role: "executive", managerId: null, status: 'Active' },
];
// # INTEGRATE: This data would come from a 'people' or 'contacts' table in your database.
export const MOCK_PEOPLE_DB = [
    { personId: 501, name: "Betsy Crabtree", linkedIn: 'linkedin.com/in/betsy' },
    { personId: 502, name: "John Carmack", linkedIn: 'linkedin.com/in/johnc' },
    { personId: 503, name: "Peter Jones", linkedIn: 'linkedin.com/in/peterj' },
    { personId: 504, name: "Rob Pike", linkedIn: 'linkedin.com/in/robpike' },
];